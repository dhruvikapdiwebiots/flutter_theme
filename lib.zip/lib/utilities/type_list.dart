enum MessageType { text, image, video, doc, location, contact, audio, messageType,gif }
enum StatusType { text, image, video}

enum PositionItemType {
  log,
  position,
}