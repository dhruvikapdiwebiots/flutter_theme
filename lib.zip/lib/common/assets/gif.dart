class GifAssets{
  final String check ="assets/gif/check.gif";
  final String wave ="assets/gif/wave.gif";
  final String message ="assets/gif/message.gif";
  final String call ="assets/gif/call.gif";
  final String status ="assets/gif/status.gif";
}