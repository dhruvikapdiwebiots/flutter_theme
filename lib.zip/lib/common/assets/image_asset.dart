class ImageAssets{
  final String splashIcon = 'assets/images/splash.png';
  final String logo = 'assets/images/logo.png';
  final String login1 = 'assets/images/login1.png';
  final String otp = 'assets/images/otp.png';
  final String line = 'assets/images/line.png';
  final String wave = 'assets/images/wave.png';
  final String phone = 'assets/images/phone.png';
  final String back = 'assets/images/back.png';
  final String user = 'assets/images/user.png';
  final String user1 = 'assets/images/user1.png';
  final String pdf = 'assets/images/pdf.png';
  final String xlsx = 'assets/images/xlsx.png';
  final String docx = 'assets/images/docx.png';
  final String jpg = 'assets/images/jpg.png';
  final String map = 'assets/images/mapview.png';
  final String noChat = 'assets/images/noChat.png';
  final String noInternet = 'assets/images/noInternet.png';
  final String logo1 =
      'https://pngimage.net/wp-content/uploads/2018/06/user-logo-png-4.png';

}